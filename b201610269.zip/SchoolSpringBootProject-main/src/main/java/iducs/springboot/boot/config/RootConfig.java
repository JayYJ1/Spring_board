package iducs.springboot.boot.config;

public class RootConfig {
}
